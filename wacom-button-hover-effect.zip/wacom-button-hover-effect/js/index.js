/*

Inspired by buttons on the new Wacom site
http://www.wacom.com/

This technique uses no extra markup besides an extended class name (.button-hover) & zero javascript

*/