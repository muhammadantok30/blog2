A Pen created at CodePen.io. You can find this one at http://codepen.io/tdevine33/pen/cjFbt.

 The new Wacom site is gorgeous.
http://www.wacom.com/

And I liked the hover effect on buttons on interior pages.
http://www.wacom.com/us/en/everyday

On their live site it uses an extra div and ahref element to achieve this effect...  so using mostly line-height and pseudo elements, I was able to create a similar css-hacky (CSS-Trick?) version with no extra markup besides a class name (ie: button-learn-more)